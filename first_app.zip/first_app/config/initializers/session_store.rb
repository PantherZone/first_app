# Be sure to restart your server when you modify this file.

FirstApp::Application.config.session_store :encrypted_cookie_store, key: '_first_app_session'
